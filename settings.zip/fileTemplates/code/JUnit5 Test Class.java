import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.mockito.kotlin.mock
import org.mockito.kotlin.verify
import org.mockito.kotlin.verifyNoMoreInteractions

#parse("File Header.java")
public class ${NAME} {
  
    @BeforeEach
    public void setUp() {
        
    }

    @AfterEach
    public void tearDown() {
        verifyNoMoreInteractions()
    }

    @Test
    public void Should() {
    
    }
}